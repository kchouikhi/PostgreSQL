#!/usr/bin/env python

from setuptools import setup

# Kept for editable install compatibility with older setuptools/pip versions
setup()
